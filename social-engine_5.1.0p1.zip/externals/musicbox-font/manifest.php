<?php return array (
  'package' => 
  array (
    'type' => 'external',
    'name' => 'musicbox-font',
    'version' => '5.1.0p1',
	'revision' => '$Revision: 9729 $',
    'path' => 'externals/musicbox-font',
	'repository' => 'socialengine.com',
    'title' => 'Musicbox Font',
    'author' => 'Webligo Developments',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
    ),
    'directories' => 
    array (
      0 => 'externals/musicbox-font',
    ),
  ),
); ?>
<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'swfobject',
    'version' => '5.1.0p1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/swfobject',
    'repository' => 'socialengine.com',
    'title' => 'Swfobject',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/swfobject',
    )
  )
) ?>
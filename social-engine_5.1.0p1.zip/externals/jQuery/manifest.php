<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'jQuery',
    'version' => '5.1.0p1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/jQuery',
    'repository' => 'socialengine.com',
    'title' => 'jQuery',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.com/license/',
    'directories' => array(
      'externals/jQuery',
    )
  )
) ?>

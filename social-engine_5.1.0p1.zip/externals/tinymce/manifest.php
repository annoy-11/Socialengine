<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'tinymce',
    'version' => '5.1.0p1',
    'revision' => '$Revision: 10267 $',
    'path' => 'externals/tinymce',
    'repository' => 'socialengine.com',
    'title' => 'TinyMCE',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/tinymce',
    )
  )
) ?>

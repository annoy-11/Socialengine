<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocomet',
    'version' => '5.1.0p1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/moocomet',
    'repository' => 'socialengine.com',
    'title' => 'Moocomet',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/moocomet',
    )
  )
) ?>
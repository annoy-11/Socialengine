<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'uploader',
    'version' => '5.1.0p1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/uploader',
    'repository' => 'socialengine.com',
    'title' => 'Uploader',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/uploader',
    )
  )
) ?>

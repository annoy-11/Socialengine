<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'flowplayer',
    'version' => '5.2.1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/flowplayer',
    'repository' => 'socialengine.com',
    'title' => 'Flow Player',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/flowplayer',
    )
  )
) ?>

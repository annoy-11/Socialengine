<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocrop',
    'version' => '5.2.1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/moocrop',
    'repository' => 'socialengine.com',
    'title' => 'Moocrop',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/moocrop',
    )
  )
) ?>

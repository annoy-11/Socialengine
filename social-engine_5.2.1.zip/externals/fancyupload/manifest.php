<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'fancyupload',
    'version' => '5.2.1',
    'revision' => '$Revision: 10171 $',
    'path' => 'externals/fancyupload',
    'repository' => 'socialengine.com',
    'title' => 'Fancy Upload',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/fancyupload',
    ),
  )
) ?>

<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moolasso',
    'version' => '5.2.1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/moolasso',
    'repository' => 'socialengine.com',
    'title' => 'Moolasso',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/moolasso',
    )
  )
) ?>

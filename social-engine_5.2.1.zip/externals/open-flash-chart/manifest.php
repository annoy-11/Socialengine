<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'open-flash-chart',
    'version' => '5.2.1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/open-flash-chart',
    'repository' => 'socialengine.com',
    'title' => 'Open Flash Chart Client',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/open-flash-chart',
    ),
  )
) ?>
